[app]

# Build from this directory: it is the complete Android app source tree.
title = Home Shooting
package.name = home_shooting
package.domain = org.homeshooting

source.dir = .
source.include_exts = py,ttf
source.exclude_dirs = .git,__pycache__,.venv,venv,bin,build,dist,tests

version = 0.1.0
requirements = python3,pygame-ce

orientation = landscape
fullscreen = 1

# The game hosts and joins LAN matches over TCP.
android.permissions = INTERNET
android.api = 33
android.minapi = 23
android.ndk = 25b
android.ndk_api = 23
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
